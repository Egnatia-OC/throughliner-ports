---
name: setup
description: Set up a project folder with the Sovereign Implementer method. Scaffolds SPEC.md, QUEUE.md, and LOG/ then interviews the user to populate them.
disable-model-invocation: true
user-invocable: true
---

# /setup

The user wants to bring this folder under the Sovereign Implementer method.

Read and follow the procedure at `${CLAUDE_PLUGIN_ROOT}/docs/setup.md`.
