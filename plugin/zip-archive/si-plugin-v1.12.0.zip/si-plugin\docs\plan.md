# /plan procedure

/plan is where captures become batches through discussion. No building happens here.

Claude owns dependency management — ordering, grouping, dependencies — through discussion, not silently.

## Ground rules

- Never build during /plan. Want to write code? Queue it.
- Batches are build, test, or audit work, in any combination. Nothing else.
- Never queue thinking work as a batch. Reviews, reconciliations/drift checks, and design exploration are planning work — their output is decisions, not changed files. Run them inside /plan; they spawn batches as output. Audit work is a separate category, not an exception: an audit is defined by its output contract — findings routed through Captures, no direct edits to the artifacts it reads. Audits produce findings, thinking work produces decisions; the two don't overlap. Test: output is decisions → planning work, run it in /plan; output is findings from a systematic read, routed to Captures → audit batch. The same test applies per seeded item, not just per batch: an audit's seeded check-items must be finding-shaped; decision-shaped checks (reconciliation, is-this-already-resolved) get resolved at planning time, not queued.
- One item at a time. Finish one before presenting the next.
- Read SPEC.md before proposing work. Don't queue contradictions.
- Process accumulated captures before new planning work.
- Never write batch entries to QUEUE.md without showing the exact text first — and the rule keys to the write, not to where you are in the loop: the message immediately before any QUEUE.md batch write must contain the entry text verbatim. Approval attaches to shown text, never to a described shape, so a recommendation — however concrete — is not a draft, and "I'll add a batch that does X" is not the entry. The reason: loop beats live in conversation memory and a compacted session loses them, but the write action is always visible, so keying the rule to the action holds even with no memory of which beat you're on.
- A recommendation is not a decision. A draft is not a written entry. Both need the user's call.
- The pipeline, when a change would make SPEC.md's description wrong or incomplete: idea → decide in /plan → spec-edit batch → /next edits SPEC → feature batch. SPEC is a normal doc now — changed only by a planned spec-edit batch that /next executes, never edited inline during /plan and never touched by a feature build. When the change touches no SPEC sentence (a refactor, a localized fix), the spec-edit stages drop out: idea → decide in /plan → feature batch. No shortcuts.
- /plan resolves what it can in-session; capture is only for what it can't. Research, queue-wide cleanup (line-ref drift, quoted-string staleness after a sweep), cross-batch reconciliation, doc verification — anything within /plan's reach — gets done now, not filed for a later session. Reserve a capture for what /plan genuinely can't resolve this session: it needs data the session doesn't have, needs design discussion across sessions, needs user input not yet available, or surfaces a structural question whose answer would gate the work. This is a default, not an absolute — the test is "can /plan resolve this with what it has right now."

## Capture and parking discipline

The control rule for capture and parking, in one place. Pieces also appear in the steps and in plugin-behaviour.md; the canonical statement is here.

- **Two structural slots for items removed from active flow.** `Blocked by:` (trigger-based, auto-surfaces — slug plus optional behavioural prose tail) and `Parked:` (indefinite, conscious revisit only — short reason). Nothing leaves active flow without one. See plugin-behaviour.md Dependency ownership for slot semantics. Applies to batches in Batches Parked and captures in Captures Parked alike.
- **Processed/unprocessed split in Captures.** Captures is divided by `---`. Processed (above) have had dependency management applied at least once and carry slugs. Unprocessed (below) are raw appended in file order. Routing (promote/park/drop) is separate from dependency management — a capture can become processed in one /plan and routed in another. See Step 2 for the loop.
- **Routing gate before recommendation.** Step 2 sub-step 2 scans capture text for references to other items before the promote/park/drop recommendation, and classifies each by linguistic marker. Forward-looking language ("once X ships," "after Y," "depends on," "needs") is a dependency and defaults the recommendation to park-with-`Blocked by:`-populated. Backward-looking language ("observed at," "see," "surfaced during," "from") is an evidence citation, does not park the capture, and is named with its role at recommend time so a wrong call stays user-catchable. Ambiguous keeps the park default, the safe side. Classification is by marker, not prose-judgment of intent.
- **Filing-time blockers go in the slot, not the prose.** When the user files a capture and the blocker is already known, write `Blocked by: [slug] + condition` inline on the capture. /plan's Step 2 dependency scan picks it up mechanically rather than re-reading the prose. Stated in plugin-behaviour.md Captures.
- **Red flags route to the Red flags section, carrying a state — not promote/park/drop.** A capture (or an in-session observation) that records a security, privacy, or breach risk Claude surfaced — per the Red flags rule in plugin-behaviour.md — moves into QUEUE.md's Red flags section at the top, never into Batches. It carries one of three states: open, resolved, or accepted (defined in plugin-behaviour.md Flag states). The state can change as the risk is discussed — open → resolved when the risk is designed out or fixed, open → accepted when the user is told the risk plainly and chooses to proceed anyway. An accepted flag's decision is recorded in the session LOG at close (see done.md) — the informed-consent trail.

## Step 1: Read state and entry question

Read QUEUE.md and SPEC.md. Check whether Captures has items.

**Plan marker at the queue top.** If the top of Batches carries a `--- Plan session here: <reason> ---` marker, addressing its stated reason is part of this session's work — that's the planning the marker was placed to force. Handle it, then remove the marker once its reason is addressed so /next is no longer halted there.

**Unpark + staleness scans:** [SILENT] before the entry question, walk Parked and the active queue against plugin-behaviour.md Dependency ownership (Unpark watch + Staleness watch). For Parked: read `Blocked by:` headers as the primary surface — slug portions fire mechanically (if the named slug has shipped, the item is a candidate; verify against LOG/index.md), behavioural prose tails still need judgment. Items marked `Parked:` (no trigger) don't auto-surface mechanically, but include them in the staleness watch on this pass — read each against whether the project has evolved past it, and carry it into Step 2 with the drop / rewrite / keep choice when it has. Meaningless accumulation is the failure mode: nothing else ever asks whether a `Parked:` item still earns its place, so this scan is where that question gets asked. For Batches and Captures: anything stale enough that surrounding code or rules have moved past it? The scans' output is candidates feeding Step 2, not findings to narrate here — collect them silently and carry them into Step 2, where they're processed ahead of Captures (see Unpark candidates first). No silent edits: every candidate goes through the Step 2 loop, where the user decides.

**Deferred-test roll scan:** [SILENT] on the same pass, read QUEUE.md's Deferred tests section. Lines whose runnability tail says Claude-runnable or user-run are rolling candidates — carry them into Step 2 as one move (roll these lines into a test batch, or attach them to a test batch being planned this session), not as per-line interviews. External-event lines stay where they are without comment.

Ask [PROMPT]: "Anything to discuss before we process Captures?" (If Captures is empty, ask what they'd like to work on.) Keep the question clean — no scan candidates folded in; they surface only inside Step 2.

**If the user has something to discuss:** Handle it via the Step 2 loop — present, interview, recommend, wait, execute. Then ask [PROMPT]: "Anything else before Captures?" Repeat until there's nothing more.

**Then process Captures:** Move to Step 2. Processing Captures is where every /plan session goes — a discussion item is just an optional first stop, never an alternative to it.

## Step 2: Process captures [SEQUENCE]

**Planning state file: _plan.md.** When capture processing begins, create `_plan.md` to hold this session's planning state: the carried unpark and staleness candidates, the item list, the current item, and the beat reached. Update it at each beat transition, and append each routed item with its disposition — promoted, parked, or dropped, with slug. One line per item, so updates stay cheap. The reason it exists: the file survives compaction, gives an interrupted /plan a resume path through session start, and hands /done a mechanical record of what was routed where instead of a reconstruction from memory. /done reads it at close and deletes it — same lifecycle as _build.md.

**Captures structure: processed/unprocessed split.** Captures is divided by `---` into processed (above) and unprocessed (below). Processed = /plan has applied dependency management at least once (given a slug, set a `Blocked by:` header, or confirmed standalone via Step 2 sub-step 2). Processed captures carry slugs so they can be cross-referenced. Unprocessed = raw appended in file order — no slug, no dependency headers yet. The divider is staging between raw and routed (promote/park/drop), not a final home — captures sit above it until routed out of Captures entirely. Routing is separate from dependency management and can happen in any later /plan: a capture can become processed in one session and routed in another.

**Unpark candidates first.** Candidates carried in from Step 1's scans are processed before Captures — Parked items have been waiting longest. Each enters the loop below as if it were a capture, sourced from Parked instead of Captures, through the same sub-steps (present + interview, recommend, execute, remove, checkpoint). The recommend options are the same three, reread for items already in Parked: **promote** means move out of Parked into Batches as a full batch entry, **park** means keep parked, **drop** removes the Parked item entirely. Staleness candidates take the same path with the Staleness watch's choice — drop, rewrite, or keep (per plugin-behaviour.md Dependency ownership).

Candidates from Step 1 first, then captures in file order, top to bottom across both halves — unprocessed below the divider, then continuing into processed above it. State the count upfront, counting candidates and captures together ("5 items. First: ..."). (Processing follows the file as placed, not strict age: a capture placed next to its relatives jumps the age queue by design. Oldest-first is only the append fallback at filing time.)

For each item:

1. **Present and interview** [DISCUSS, PROMPT] — Open the turn with a one-line preamble (e.g. "here's the next item, my thoughts to follow") and the item's verbatim text, sent before any analysis or file reads begin. Why the quote lands first, and on its own: the user processes the item more easily when they can take in the raw text before Claude's framing arrives, rather than digesting Claude's whole reaction the moment it all lands bundled. It's availability, not obligation — the quote-first beat gives the user the *option* to read and react before the analysis, and they stay free to pre-empt with a disposition or to read straight on. Steer between two failure modes: **bundling** (the quote tangled with analysis in one paragraph, so the user can't take the raw item in first) and **forced-wait** (stopping after the quote and gating the analysis behind the user's reply, which blocks a user who'd rather read on). The correct shape is the quote first as its own beat, the analysis following in the same flow. The separator that makes this a send rather than a paragraph: after the quote goes out, re-read the item from QUEUE.md to confirm the quoted text matches the file — this read forces the quote out as its own beat, and it catches a context-drifted quote before it's discussed (if the file differs, correct it immediately). Only then engage with the item's substance: ask follow-ups to sharpen it or surface missing context, depth scaling with the item, until the picture is clear. Close: "anything else to add?" Unpark candidates enter this loop the same way.

2. **Dependency scan** [SILENT] — Before recommending, scan the capture text for references to other items (slugs in `[brackets]`, bold titles, named work) and classify each by the language that frames it, not by guessing intent:
   - **Forward-looking** ("once X ships," "after Y has run," "depends on Z," "needs W") — a dependency. The default recommendation in sub-step 3 becomes park-with-`Blocked by:`-populated.
   - **Backward-looking** ("observed at," "see," "surfaced during," "from") — an evidence citation, not a dependency, so it does not park the capture. The capture-authoring standard asks for origin and reasoning, so evidence citations are common; a citation must not block the work it cites. When a reference is classified as evidence, sub-step 3's recommendation names the reference and its role (citation), so a wrong classification stays catchable by the user.
   - **Ambiguous** — keep the park default, the safe side.
   If no reference is found, give the capture a kebab-case slug (if unprocessed) — it's now processed and stays above the divider whether or not it gets routed this session. Classify by linguistic marker, not prose-judgment of intent.

3. **Recommend** [PROMPT] — Recommend a route — promote, park, or drop, or (for a red flag) move it to the Red flags section — and say why:
   - **Promote** — ready to become a batch. The recommendation must describe what would actually get built, in terms the user can recognize as the work product (which files change, what subsection or rule, what gets added/removed/rewritten — not just the topic or intent). Forcing function: if sub-step 1's interview hasn't yielded enough to describe the outputs concretely, the recommendation isn't ready — return to interviewing. **Downstream-impact scan:** if the capture installs a *structural rule* (defines what something is, sets a constraint that frames how other captures get evaluated — as opposed to a localized fix), scan the remaining Captures for items that could revise or invalidate the rule. Trigger is rule shape, not edit size. If any are found, flag at recommend time, name the conflict, and offer three options — process the downstream capture first, hold this one, or proceed accepting the possible later revision.
   - **Park** — not now, keep for later. If sub-step 2 found a dependency, this is the default and `Blocked by:` is populated from the scan. Otherwise park with a short `Parked:` reason.
   - **Drop** — remove it
   - **Red flag** — the item records a security, privacy, or breach risk Claude surfaced (per plugin-behaviour.md Red flags). It routes to the Red flags section with a state instead of becoming a batch — see Capture and parking discipline. Recommend its state: open if unaddressed, resolved if the discussion designs the risk out, accepted if the user is told the risk plainly and still chooses to proceed.
   Stop and wait. The user decides.

4. **Execute promote, park, drop, or red-flag routing:**
   - **Promote** [DISCUSS, PROMPT] — Draft the batch entry (bold title, prose rationale, Build/Test subheadings). The rationale carries the discussion's reasoning as inline prose — see Why-pipeline in plugin-behaviour.md. Show the draft as a blockquote with a content-type lead-in (**Batch draft:**), per the approval-time outputs rule in plugin-behaviour.md. Don't write to QUEUE.md until approved. Claude places the batch using dependency ordering and reports where it went.
   - **Park** — Move to Parked with the `Blocked by:` or `Parked:` header populated per sub-steps 2 and 3.
   - **Drop** — Remove. If already decided (check LOG/index.md), state the prior decision and commit.
   - **Red flag** — Move the item into QUEUE.md's Red flags section at the top, written with its state (open, resolved, or accepted). When the state is accepted, done.md records the decision in the session LOG at close — what the user was warned about and that they chose to proceed.

5. Remove the item from Captures once routed (promote, park, drop, or moved to the Red flags section). If only dependency management was applied this turn — slug given or `Blocked by:` set without routing — the capture stays in Captures but moves above the divider as a processed item; don't remove it.

6. **Checkpoint** [PROMPT] — After every item, all three off-ramps must be available: continue to the next capture, close out now (go to Step 4), or share something else (loop back into Step 2 with the new item). Deliver them conversationally — they don't need identical wording each time, only to all be genuinely on offer, so the checkpoint reads as a natural pause rather than a form to fill in. Wait for the user's call. On the last capture, "continue to the next" drops out naturally — the offer becomes the remaining two.

After all items: Captures should hold only processed items above the divider (or be empty if everything was routed). Section header, divider, and `### Parked` intact.

New items from conversation follow the same loop — check QUEUE.md for overlap first.

If Claude notices a gap: "I notice [X] — want to hear a suggestion?"

## Step 3: Batch structure

```markdown
**Batch title** **[batch-slug]**
Depends on: [other-slug], [other-slug]
Blocks: [other-slug]

[Prose rationale — one or more sentences. What motivated this work, what's broken or missing, what changes once it lands.]

Build:
- What to build

Spec-edit:
- Which SPEC.md section or sentence changes, and to what

Test:
- How to verify

Audit:
- Target: which docs, files, or area to review
- Criteria: what to look for (repetition, drift, tag misuse, prose-where-tag-belongs, etc.)

Freeform:
- What the work is, and one line on why it's not a build, a test, or an audit
```

Bold title with a stable kebab-case slug appended as a `**[slug]**` marker, then optional `Depends on:` / `Blocks:` header lines (omit either when empty — no `Depends on: none` placeholders), then the prose rationale, then entries under Build, Test, and/or Audit subheadings. See plugin-behaviour.md Dependency ownership for the slug and header rules. Each entry names its own target. The rationale is inline prose (no `Why:` label, no separate field) and carries the reasoning forward — /next copies it to _build.md, /done re-authors it into the LOG entry. See Why-pipeline in plugin-behaviour.md.

**Spec-edit batches.** SPEC.md is a normal doc, changed only through a spec-edit batch — never edited inline during /plan, never touched by a feature build. When a planned change would make SPEC.md's description wrong or incomplete — a new capability, a scope change, a new output type, with the test being whether any sentence in SPEC goes wrong — author a spec-edit batch first: its `Files:` list names SPEC.md, and its Spec-edit entries say which sentences change and to what. /next executes it like any build (the scope-lock allows SPEC because the batch lists it), and /done closes it like any build. Queue the dependent feature batch after it. A refactor or localized fix that changes no SPEC sentence needs no spec-edit batch.

**Freeform batches.** Freeform is the home for planned work that isn't a build, a test, or an audit — an ad-hoc change, a discussion of edits already made, something to surface without the pressure of processing it. When scoping a Freeform batch, run the same gate the on-demand `/next freeform` runs: could this work be a build, a test, or an audit instead? Those three have homes already, so freeform is only for what fits none of them. The entry carries one line naming why none fit — that line is the gate's answer, written into the batch so /next inherits it. Freeform scope is granted ask-by-ask during the build, so its entries needn't name files; the lock starts at method-docs-only.

**Build entries name their files.** A build entry names the files it touches — the scope-lock's `Files:` list in _build.md is populated from those names, so build scope gets decided here at planning time instead of ask-by-ask during the build (see plugin-behaviour.md Scope). A file that doesn't exist yet counts as named when the entry says what gets created and where. A batch whose entries name no files to edit (audit batches, test-only batches) leaves the lock at method-docs-only.

**Think through testing when drafting.** Before authoring the Test section (or deciding to omit it), work through what verification this batch needs. Split the question two ways: what Claude can verify itself (read files, run commands, trace logic, inspect output), and what needs the user (visual, physical, subjective, separate live session). Populate Test with what you find — or proceed without one when the change is self-verifying from the build entries. The decision to omit gets made consciously, not by inattention.

**Test section:** Only when there's a behaviour to verify that isn't self-evident from build entries. Not every batch needs one — but /done doesn't generate tests, so anything needing verification must be planned here. [SILENT] when omitting — the rationale already tells the user what kind of change it is.

Split test entries by who runs them, per the thinking above. Write each so /next knows which kind.

**Roll in deferred tests.** When authoring a test batch, check QUEUE.md's Deferred tests section for pending Claude-runnable or user-run lines that can ride along, and move each rolled line out of the section into this batch's Test entries. This is the execution channel for the Step 1 roll scan — the deferred backlog reaches a runnable session through a test batch, not through a separate listing.

**E2E tests get their own batch.** User-run E2E tests (separate project, live session) don't go in build batches — they'd block the build flow.

**Readiness gate** (per batch): can you write the candidate index entry now — artifact touched + nature of the change, per plugin-behaviour.md Index entries? If yes, the batch is ready and the entry can be pre-generated for /next to carry into _build.md. If no, the batch isn't coherent enough yet — keep interviewing. Matching scope check: can the `Files:` list be populated from these entries — does each build entry name the files it touches, or consciously name none (audit and test-only batches)? If the files can't be named yet, the entries aren't concrete enough — keep interviewing.

**Audit batch sizing gate:** for audit batches, the readiness check is whether target and criteria are specific enough that Claude can write the audit prompt without further dialogue. If the target is vague ("the docs", "the UI flows") or the criteria open-ended ("anything off"), keep interviewing until both pin down.

**Ordering:** Claude places by dependency where applicable — dependencies first, then scaffolding, features, polish. Oldest-first is the fallback when no dependency applies (per plugin-behaviour.md Captures placement). Either way, Claude reports placement and reasoning per Dependency ownership narration — including the explicit "appending here because no dependency applies" case.

**Plan markers — write predictable planning moments into the queue.** When placement creates a spot where a planning session must happen before /next can continue, insert a marker line between the batches at that spot: `--- Plan session here: <reason> ---`, with the reason stated inline. Two cases illustrate when (not a closed list): an audit batch sits ahead of batches that depend on its findings, so those findings must be processed in /plan before the dependent work can be scoped; or a batch's dependencies wait on a design question no planning session has answered yet, so /plan must settle it first. The marker converts a judgment-based "you should run /plan around here" into a mechanical gate /next halts on — the same shape as the push marker. It's a floor, not a ceiling: planning must happen here at minimum, for the stated reason; ad-hoc /plan anywhere else stays unrestricted.

## Step 4: Close out [BRIEF, PROMPT]

"Run /done to record this and commit, or keep planning." No chat summary — the LOG entry /done writes is the single session summary.
