# Build procedure

Execution procedure for build batches. Reached from next.md after pre-flight checks and scope lock are complete.

## Execute [SILENT]

Execute entry by entry.

The silence here governs the success path — the routine bookkeeping of making changes and ticking entries when things go fine. It is not a gag on the moments that must speak: reporting a failure, asking before scope grows, and handing a test to the user all speak. A response-shape tag on one of those specific moments overrides this step's silence — that's the precedence rule working as intended, not a conflict.

### Build entries

For each:

1. Read any relevant existing code or context.
2. Make the changes.
3. Tick it in _build.md Progress: `- [x] entry description — done`

### Test entries

When the batch contains test entries (under a Test subheading), execution is verification, not file editing:

1. Read the test description to understand what's checked.
2. Run every test you can verify yourself: read code, run commands, inspect output, check file content. Only tests needing real human interaction (visual appearance, physical device behaviour, subjective judgment) go to the user — handing one over is a speaking moment: [PROMPT] state what you need the user to check and wait.
3. Tick each in _build.md Progress, pass/fail:
   - `- [x] Test description — ✓`
   - `- [x] Test description — ✗ (reason)`
   - `- [x] Test description — deferred (reason)` — written the moment a test is determined unrunnable in this session (host-side, needs the user, waiting on an external event). Records the determination in the file so a post-/clear /done doesn't misread the entry as unfinished work.
4. Accumulate results in Changes: what was checked, what passed, what failed.

**On test failure:**
- Isolated (one test, rest unaffected): [BRIEF] note it, continue, route the fix to Captures at close.
- Fundamental (invalidates the batch premise or blocks remaining tests): stop, go to Course-correction below.

### Rules during build

Absolute regardless of entry type:

- Stay within the active batch's described work — that's build scope (see plugin-behaviour.md Scope). Growing past it needs approval first (see Scope management below).

**Accumulate close notes** as you go — jot what changed in _build.md so /done needn't re-explore:
```
Changes:
- file1.ext: created new component, 45 lines
- file2.ext: added import + handler function
- [test] walked through mixed batch scenario — ✓, procedure unambiguous
```

## Scope management

These sections elaborate the discovery decision rule in plugin-behaviour.md (Routing and discipline): work needed to complete the batch is added or split; work not needed is captured and the session continues. The cases below are how that rule plays out during a build.

### User raises something out of scope [PROMPT]

1. Route it to Captures in QUEUE.md, placed per plugin-behaviour.md Captures placement (Claude-directed where applicable, oldest-first as fallback — narrate the placement). Draft the wording first as a blockquote with a content-type lead-in (**Capture draft:**) for approval, per plugin-behaviour.md (Captures + approval-time outputs).
2. Ask "anything else?" — repeat until no.
3. Resume the build.

**Coherence exception:** Default is capture, per above. The exception is narrow and keyed to why-pipeline coherence: if the item would share the build's log entry and index line — per plugin-behaviour.md Index entries — and folding it in makes the batch easier to find later rather than harder, add it to _build.md as a new entry (appending any files it names to the `Files:` section) and continue. Evaluate against the coherence rules, not user convenience. When uncertain, capture.

### Scope grows during the build [PROMPT]

Both paths below ask and wait, so the tag sits on the whole section. If the work needs to grow past what the entries describe — whether that means a new file or more change inside a file already listed — the trigger is the same: growth is measured against the described work, not the Files: list. Name the new work and the files it needs, then:

- **Minor** (a small prerequisite, one or two files): ask to add, naming the work and the files: "This needs [work], which means editing [file] — add it to scope?" Once approved, append any not-yet-listed file to _build.md's `Files:` section before editing it — the scope-lock denies edits to unlisted files.
- **Significant** (multiple new files, design uncertainty): propose splitting. Finish what's scoped, /done to close, then /plan to queue the rest.

## Mid-build course-correction

### Claude discovers user-runnable testing is needed [PROMPT]

When Claude notices something will need user-runnable testing beyond the batch's Test section — visual check, physical-device behaviour, subjective judgment Claude can't verify:

1. Route the discovery to Captures in QUEUE.md as a future test-only batch. Draft the wording (what needs testing and why), show before writing per plugin-behaviour.md Captures.
2. Ask "anything else?" — repeat until no.
3. Resume the build.

Don't attempt the test inline. Don't extend the current batch's scope to include it.

### Approach not working [DISCUSS, PROMPT]

If something goes wrong — a false assumption, a missing dependency, an approach that isn't working:

1. **Stop building.** Don't push through a broken approach.
2. **State the problem plainly.** What you expected, what happened, why the current approach won't work.
3. **Propose a path forward:**
   - **Adjust scope:** drop an entry, add a prerequisite, change the approach. Update _build.md to match.
   - **Abort and requeue:** if the whole batch is unsalvageable:
     1. Return the batch text to QUEUE.md under Batches. Placement is Claude's call per plugin-behaviour.md Dependency ownership — original position or top, by what was learned.
     2. Route any captures surfaced during the attempt to Captures as normal.
     3. Route the reshape direction to Captures, pointing at the batch slug. The trigger is mechanical: abort + batch returned + a reshape direction or learning the queue needs in conversation = capture needed. Unrouted, the direction survives only in the LOG entry, which /plan doesn't read at planning time, and the batch re-presents unchanged at the next /next.
     4. Tell the user to run /done. _build.md stays in place so /done's router still fires the build close-out — see done.md. Differences from a completed build: the LOG entry describes the attempt and why it was aborted, and the batch returns to QUEUE.md rather than disappearing into the log.
4. **Wait for the user's call.** Don't pick a path without confirmation.

## Context management

If context is running low, prefer in order:

1. **Finish and /done.** If most entries are ticked, push through. Short-term memory is enough.
2. **Close partial.** If significant work remains, /done what's ticked and requeue the rest. The next session picks up cleanly from _build.md and QUEUE.md.

## Completion [BRIEF, PROMPT]

When all entries are ticked:

1. Tell the user the build is complete.
2. Say: "Run /done to record this and commit, or tighten what's already built before closing." Tightening means refining done entries — not raising new work. Anything new routes through the existing paths: out-of-scope via Scope management above, thinking work via Captures. No chat summary of the changes — the LOG entry /done writes is the single session summary.

Do NOT delete _build.md yourself. That's /done's job.
